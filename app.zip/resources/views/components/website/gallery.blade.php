 <section class="pt-16 md:pt-28" id="publikasi">
     <div class="w-full px-4 sm:px-6 lg:px-8 mx-auto">
         <div class="text-center mb-5">
             <h1 class="text-utama text-3xl md:text-5xl font-semibold">Gallery</h1>
             <h4 class="text-gray-400 text-sm md:text-xl mt-2">Fiqri Andra, S.Sos., MM.</h4>
         </div>

         <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
             <div>
                 <img class="h-auto max-w-full rounded-lg" src="{{ asset('image/haaland.jpg') }}" alt="">
             </div>
             <div>
                 <img class="h-auto max-w-full rounded-lg" src="{{ asset('image/peb.jpg') }}" alt="">
             </div>
             <div>
                 <img class="h-auto max-w-full rounded-lg" src="{{ asset('image/kdb.jpg') }}" alt="">
             </div>
             <div>
                 <img class="h-auto max-w-full rounded-lg"
                     src="https://flowbite.s3.amazonaws.com/docs/gallery/square/image-3.jpg" alt="">
             </div>
             <div>
                 <img class="h-auto max-w-full rounded-lg"
                     src="https://flowbite.s3.amazonaws.com/docs/gallery/square/image-4.jpg" alt="">
             </div>
             <div>
                 <img class="h-auto max-w-full rounded-lg"
                     src="https://flowbite.s3.amazonaws.com/docs/gallery/square/image-5.jpg" alt="">
             </div>
         </div>
     </div>
 </section>
