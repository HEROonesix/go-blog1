<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH D:\laragon\www\go-blog\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>