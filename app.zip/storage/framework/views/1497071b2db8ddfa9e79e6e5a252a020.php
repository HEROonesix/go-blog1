<section class="pt-16 md:pt-28" id="jejak-digital">
    <div class="w-full mx-auto">
        <div class="text-center mb-5">
            <h1 class="text-utama text-3xl md:text-5xl font-semibold">Blog</h1>
            <h4 class="text-gray-400 text-sm md:text-xl mt-2">Fiqri Andra, S.Sos., MM.</h4>
        </div>
        <section class="bg-white dark:bg-gray-900">
            <div class="py-8 px-4 mx-auto max-w-screen-xl lg:py-16">
                <div class="grid md:grid-cols-3 gap-8">
                    <div
                        class="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-8 md:p-12">
                        <a href="#">
                            <img class="rounded-t-lg w-full" src="<?php echo e(asset('image/kdb.jpg')); ?>" alt="" />
                        </a>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                                    Kevin De Bruyne</h5>
                            </a>
                            <h2 class="text-gray-900 dark:text-white text-3xl font-extrabold mb-2">Pemain</h2>
                            <p class="text-lg font-normal text-gray-500 dark:text-gray-400 mb-4">Kevin De Bruyne
                                adalah seorang pemain professional sepak bola asal Belgia yang bermain untuk
                                Manchester City di Liga Utama Inggris dari posisi gelandang dan timnas Belgia yang
                                juga dalam posisi gelandang</p>
                            <a href="#"
                                class="text-blue-600 dark:text-blue-500 hover:underline font-medium text-lg inline-flex items-center">Read
                                more
                                <svg aria-hidden="true" class="w-4 h-4 ml-2" fill="none" stroke="currentColor"
                                    stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3">
                                    </path>
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div
                        class="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-8 md:p-12">
                        <a href="#">
                            <img class="rounded-t-lg w-full" src="<?php echo e(asset('image/peb.jpg')); ?>" alt="" />
                        </a>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                                    Peb
                                    Guardiola</h5>
                            </a>
                            <h2 class="text-gray-900 dark:text-white text-3xl font-extrabold mb-2">Menajer</h2>
                            <p class="text-lg font-normal text-gray-500 dark:text-gray-400 mb-4">Static Josep pep
                                Guardiola
                                Sala
                                (lahir 18 Januari 1971) merupakan seorang mantan pemain sepak bola Barcelona, yang
                                sejak
                                2016
                                melatih F.C Manchester City. Ia dahulu berposisi sebagai gelandang bertahan. Ia
                                melatih
                                Barcelona sejak 2008 hingga Juni 2012 dan mulai awal musim 2013–14 menjadi pelatih
                                FC Bayern
                                München. Ia juga pernah bermain untuk tim nasional Spanyol dan tim nasional
                                Catalunya.</p>
                            <a href="#"
                                class="text-blue-600 dark:text-blue-500 hover:underline font-medium text-lg inline-flex items-center">Read
                                more
                                <svg aria-hidden="true" class="w-4 h-4 ml-2" fill="none" stroke="currentColor"
                                    stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3">
                                    </path>
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div
                        class="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-8 md:p-12">
                        <a href="#">
                            <img class="rounded-t-lg w-full" src="<?php echo e(asset('image/haaland.jpg')); ?>" alt="" />
                        </a>
                        <div class="p-5">
                            <a href="#">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                                    Haaland
                                </h5>
                            </a>
                            <h2 class="text-gray-900 dark:text-white text-3xl font-extrabold mb-2">Top skor liga
                                inggris
                            </h2>
                            <p class="text-lg font-normal text-gray-500 dark:text-gray-400 mb-4">Static Haaland
                                menjebol
                                gawang
                                West Ham pada menit ke-70. Ia mencetak gol kedua bagi timnya, melengkapi torehan
                                Nathan Ake
                                dan
                                Phil Foden.
                                Itu merupakan gol ke-35 dari Haaland di Liga Inggris musim ini. Ia kini sudah
                                melewati rekor
                                Alan Shearer dan Andy Cole sebagai pemain pertama yang menembus angka tersebut di
                                era
                                Premier
                                League.</p>
                            <a href="#"
                                class="text-blue-600 dark:text-blue-500 hover:underline font-medium text-lg inline-flex items-center">Read
                                more
                                <svg aria-hidden="true" class="w-4 h-4 ml-2" fill="none" stroke="currentColor"
                                    stroke-width="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3">
                                    </path>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="grid grid-cols-1 splide">
            <div class="splide__track">
                <div class="splide__list">
                </div>
            </div>
        </div>


    </div>
</section>
<?php /**PATH D:\laragon\www\go-blog\resources\views/components/website/blog.blade.php ENDPATH**/ ?>