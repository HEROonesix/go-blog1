<h2 <?php echo e($attributes->class(['text-xl font-semibold tracking-tight filament-card-heading'])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH D:\laragon\www\go-blog\vendor\filament\filament\src\/../resources/views/components/card/heading.blade.php ENDPATH**/ ?>