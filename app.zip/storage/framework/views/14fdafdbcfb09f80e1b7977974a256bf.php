<!DOCTYPE html>
<html lang="en" class="scroll-smooth">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="UfqLMCQ2PLjk7xQf18iSXji2gQa1R13XtLLZMpnO">

    <title>Go-blog</title>

    <link rel="shortcut icon" href="<?php echo e(asset('image/city.jpg')); ?>" type="image/x-icon">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="font-sans antialiased bg-gray-50">
    <?php if (isset($component)) { $__componentOriginal416b30176726f71a2e4965def925a4f3 = $component; } ?>
<?php $component = App\View\Components\Website\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Website\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal416b30176726f71a2e4965def925a4f3)): ?>
<?php $component = $__componentOriginal416b30176726f71a2e4965def925a4f3; ?>
<?php unset($__componentOriginal416b30176726f71a2e4965def925a4f3); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginal8c62dab9f241c09fcb6e7f5d26bfc6ea = $component; } ?>
<?php $component = App\View\Components\Website\Hero::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Website\Hero::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c62dab9f241c09fcb6e7f5d26bfc6ea)): ?>
<?php $component = $__componentOriginal8c62dab9f241c09fcb6e7f5d26bfc6ea; ?>
<?php unset($__componentOriginal8c62dab9f241c09fcb6e7f5d26bfc6ea); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginal64c571a5c19c584f3c6c8b2ec9196404 = $component; } ?>
<?php $component = App\View\Components\Website\Tabs::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.tabs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Website\Tabs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64c571a5c19c584f3c6c8b2ec9196404)): ?>
<?php $component = $__componentOriginal64c571a5c19c584f3c6c8b2ec9196404; ?>
<?php unset($__componentOriginal64c571a5c19c584f3c6c8b2ec9196404); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginal5b75ff0c9baa7aebf9114e8c5c509fa5 = $component; } ?>
<?php $component = App\View\Components\Website\Blog::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Website\Blog::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b75ff0c9baa7aebf9114e8c5c509fa5)): ?>
<?php $component = $__componentOriginal5b75ff0c9baa7aebf9114e8c5c509fa5; ?>
<?php unset($__componentOriginal5b75ff0c9baa7aebf9114e8c5c509fa5); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginal8cdba74be2d04cc12b5cf815e4f561a3 = $component; } ?>
<?php $component = App\View\Components\Website\Gallery::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.gallery'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Website\Gallery::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cdba74be2d04cc12b5cf815e4f561a3)): ?>
<?php $component = $__componentOriginal8cdba74be2d04cc12b5cf815e4f561a3; ?>
<?php unset($__componentOriginal8cdba74be2d04cc12b5cf815e4f561a3); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginalaf816b459a1e0cb972ab8af7c650cd9d = $component; } ?>
<?php $component = App\View\Components\Website\Kontak::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.kontak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Website\Kontak::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf816b459a1e0cb972ab8af7c650cd9d)): ?>
<?php $component = $__componentOriginalaf816b459a1e0cb972ab8af7c650cd9d; ?>
<?php unset($__componentOriginalaf816b459a1e0cb972ab8af7c650cd9d); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginal7d09d9567fe432e4349b6d7625e720f9 = $component; } ?>
<?php $component = App\View\Components\Website\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Website\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d09d9567fe432e4349b6d7625e720f9)): ?>
<?php $component = $__componentOriginal7d09d9567fe432e4349b6d7625e720f9; ?>
<?php unset($__componentOriginal7d09d9567fe432e4349b6d7625e720f9); ?>
<?php endif; ?>



</body>

</html>
<?php /**PATH D:\laragon\www\go-blog\resources\views/welcome.blade.php ENDPATH**/ ?>